package com.example.areas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    double area = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toast.makeText(getBaseContext(),"Welcome to Shapes Calculate App",Toast.LENGTH_LONG).show();

        Spinner sp_shapes = findViewById(R.id.areas_sp_shapes);
        EditText et_rectangle_width = findViewById(R.id.areas_et_rectangle_width);
        EditText et_rectangle_hieght = findViewById(R.id.areas_et_rectangle_high);
        EditText et_circle_radius = findViewById(R.id.areas_et_circle_radius);
        EditText et_triangle_base = findViewById(R.id.areas_et_triangle_base);
        EditText et_triangle_height = findViewById(R.id.areas_et_triangle_hieght);
        TextView tv_result = findViewById(R.id.areas_tv_result);
        Button btn_calculate = findViewById(R.id.areas_btn_calculate);

        // Circle -> pi * r * r
        // Rectangle -> w * h
        // Triangle -> 0.5 * base * h


        sp_shapes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0:
                        //Rectangle
                        et_rectangle_hieght.setVisibility(View.VISIBLE);
                        et_rectangle_width.setVisibility(View.VISIBLE);
                        et_circle_radius.setVisibility(View.GONE);
                        et_triangle_base.setVisibility(View.GONE);
                        et_triangle_height.setVisibility(View.GONE);
                        break;
                    case 1:
                        //Circle
                        et_rectangle_hieght.setVisibility(View.GONE);
                        et_rectangle_width.setVisibility(View.GONE);
                        et_circle_radius.setVisibility(View.VISIBLE);
                        et_triangle_base.setVisibility(View.GONE);
                        et_triangle_height.setVisibility(View.GONE);
                        break;
                    case 2:
                        //Triangle
                        et_rectangle_hieght.setVisibility(View.GONE);
                        et_rectangle_width.setVisibility(View.GONE);
                        et_circle_radius.setVisibility(View.GONE);
                        et_triangle_base.setVisibility(View.VISIBLE);
                        et_triangle_height.setVisibility(View.VISIBLE);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btn_calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            int indexSp = sp_shapes.getSelectedItemPosition();


            switch (indexSp) {
                case 0:
                    //Rectangle
                    double rect_width = Double.parseDouble(et_rectangle_width.getText().toString());
                    double rect_height = Double.parseDouble(et_rectangle_hieght.getText().toString());
                    area = rect_width * rect_height;
                    break;
                case 1:
                    //Circle
                    double circ_radius = Double.parseDouble(et_circle_radius.getText().toString());
                    area = Math.PI * Math.pow(circ_radius,2);
                    break;
                case 2:
                    //Triangle
                    double tri_base = Double.parseDouble(et_triangle_base.getText().toString());
                    double tri_height = Double.parseDouble(et_triangle_height.getText().toString());
                    area = 0.5 * tri_base * tri_height;
                    break;
            }
            tv_result.setText(area+"");
            }
        });


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Toast.makeText(getBaseContext(),"Area is : "+area,Toast.LENGTH_LONG).show();
    }
}